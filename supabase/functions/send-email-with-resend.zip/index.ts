// Simple email sending function using Resend API with proper CORS headers
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import * as xlsx from "https://cdn.sheetjs.com/xlsx-0.19.3/package/xlsx.mjs";
import { encode as encodeBase64 } from "https://deno.land/std@0.168.0/encoding/base64.ts";
import { WorkReportData } from "../_shared/types.ts";

// Define CORS headers that will work with any origin
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Define expected payload structure
interface EmailPayload {
  to: string;
  subject: string;
  text: string;
  reportData: WorkReportData;
  format: 'excel' | 'pdf' | 'csv';
}

// Get Resend API key from environment variables
const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY');

const handler = async (request: Request): Promise<Response> => {
  console.log("---> RUNNING send-email-with-resend function <---");

  // Handle preflight request
  if (request.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    if (!RESEND_API_KEY) {
      throw new Error('RESEND_API_KEY is not set in environment variables');
    }

    // Parse the request body
    const payload: EmailPayload = await request.json();
    console.log(`Received email request for: ${payload.to}`);

    // Validate payload
    if (!payload.to || !payload.reportData) {
      throw new Error('Missing required fields in payload');
    }

    // Generate attachment based on format
    let attachmentContent: string;
    let attachmentFilename: string;
    let attachmentContentType: string;

    const { reportData, format } = payload;
    const filenameBase = `Arbeitsrapport_${reportData.employeeName || 'Mitarbeiter'}_${reportData.month || 'Monat'}-${reportData.year || 'Jahr'}`.replace(/\s+/g, '_');

    // Generate Excel attachment
    if (format === 'excel') {
      console.log('Generating Excel attachment...');
      const wb = xlsx.utils.book_new();
      
      // Create header row and data rows
      const wsData = [
        ["Client:", reportData.client || 'Kunde'],
        ["Month:", reportData.month || 'Monat'],
        ["Year:", reportData.year || 'Jahr'],
        ["Employee:", reportData.employeeName || 'Mitarbeiter'],
        ["Total Hours:", reportData.totalHours || 0],
        [], // Empty row
        ["Date", "Project", "Description", "Hours"] // Header row
      ];

      // Add entries
      reportData.entries.forEach(entry => {
        wsData.push([
          entry.date || '',
          entry.project || '',
          entry.description || '',
          entry.hours || 0
        ]);
      });

      // Add worksheet to workbook
      const ws = xlsx.utils.aoa_to_sheet(wsData);
      xlsx.utils.book_append_sheet(wb, ws, "Work Report");

      // Generate Excel file
      const excelBuffer = xlsx.write(wb, { type: 'array', bookType: 'xlsx' });
      attachmentContent = encodeBase64(new Uint8Array(excelBuffer));
      attachmentFilename = `${filenameBase}.xlsx`;
      attachmentContentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    } else {
      // For simplicity, we'll only implement Excel for now
      throw new Error(`Format ${format} is not supported yet`);
    }

    // Create HTML content for the email
    const htmlContent = `
      <html>
        <body>
          <p>Sehr geehrte Damen und Herren,</p>
          <p>Anbei erhalten Sie den Arbeitsrapport für ${reportData.month || 'Monat'}/${reportData.year || 'Jahr'}.</p>
          <p><strong>Zusammenfassung:</strong></p>
          <ul>
            <li>Gesamtstunden: ${(reportData.totalHours || 0).toFixed(2)}</li>
          </ul>
          <p>Mit freundlichen Grüßen,<br>${reportData.employeeName || 'Mitarbeiter'}</p>
        </body>
      </html>
    `;

    // Send email using Resend API
    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: 'onboarding@resend.dev', // Change this to your verified domain
        to: payload.to,
        subject: payload.subject || `Arbeitsrapport: ${reportData.employeeName || 'Mitarbeiter'} - ${reportData.month || 'Monat'}/${reportData.year || 'Jahr'}`,
        html: htmlContent,
        text: payload.text || `Arbeitsrapport für ${reportData.month || 'Monat'}/${reportData.year || 'Jahr'}`,
        attachments: [
          {
            filename: attachmentFilename,
            content: attachmentContent,
            encoding: 'base64',
            type: attachmentContentType
          }
        ]
      }),
    });

    const data = await res.json();
    console.log('Resend API response:', data);

    // Return the response with CORS headers
    return new Response(JSON.stringify({
      success: true,
      messageId: data.id || 'unknown',
      details: data
    }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders,
      },
    });
  } catch (error) {
    console.error('Error sending email:', error);
    
    // Return error response with CORS headers
    return new Response(JSON.stringify({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
      details: error instanceof Error ? error.stack : null
    }), {
      status: 500,
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders,
      },
    });
  }
};

// Start the server
serve(handler);
